
class StoryBean {
  final String name;
  final String email;
  final String storyUrl;

  StoryBean({this.name, this.storyUrl, this.email});
}